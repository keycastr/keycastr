- Ilya Kulakov, <kulakov.ilya@gmail.com>: Current maintainer
- [Contributors](https://github.com/Kentzo/ShortcutRecorder/graphs/contributors)

Initial developers:
- Jesper, waffle software, <wootest+shortcutrecorder@gmail.com>: Initial idea and concept
- David Dauer, <david@daviddauer.de>: Initial implementation
- Jamie Kirkpatrick, Kirk Consulting Ltd, <jkp@kirkconsulting.co.uk>: Further modularisation, re-factoring and general bug fixes
- Andy Kim
- Silvio Rizzi
